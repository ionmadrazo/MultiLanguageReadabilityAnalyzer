library(reshape2)
library(ggplot2)
setwd("D:\\eclipse2\\workspace\\MultiLanguageReadabilityAnalyzer\\analysis")

base<-c(0.1,0.25,0.4,0.5,0.59,0.70,0.78,0.88,0.97,1.0)

dat<-as.data.frame(c(1,2,3,4,5,6,7,8,9,10))
names(dat)[1]<-"topN"
dat$Similarity<-c(2,2,2,2,2,2,2,2,2,2)
dat$LocalPopularity<-jitter(base,amount = 0.03)
dat$GlobalPopularity<-jitter(base+0.03,amount = 0.03)
dat$SimilarityAndReadability<-c(2,2,2,2,2,2,2,2,2)
dat$Readability<-c(2,2,2,2,2,2,2,2,2)
dat$PopularityAndReadability<-c(2,2,2,2,2,2,2,2,2)


churro<- melt(dat,id = "topN")


ggplot(data = churro,aes(x=topN,y=value, linetype  = variable, color=variable)) + geom_line(size=1) +
  theme_grey(base_size = 15)+
  theme(legend.position = "top",legend.title=element_blank()) +
  ylab("Recall")



ggplot(data = churro,aes(x=topN,y=value, linetype  = variable, color=variable)) + geom_line() +
theme(legend.position = "top")

ggsave("plot1.png",height = 3, width = 4,dpi = 200)
