package textProcessors;

import datasetHelpers.Dataset;
import processors.DatasetProcessor;

public class Tokenizer  implements DatasetProcessor{

	@Override
	public void process(Dataset d) {
		// TODO Auto-generated method stub
		
	}

}
