package constants;

public class TagKeys {

	public static final String TAG_WORDFORM = "TAG_WORDFORM";
	public static final String TAG_LANGUAGE = "TAG_LANGUAGE";
	public static final String TAG_FOLDER = "TAG_FOLDER";
	public static final String TAG_FILENAME = "TAG_FILENAME";
	public static final String TAG_LEMMA_CHARLENGTH_AVERAGE = "TAG_LEMMA_CHAR_LENGTH_AVERAGE";	
	public static final String TAG_POS_PREFIX = "TAG_POS_";
}
