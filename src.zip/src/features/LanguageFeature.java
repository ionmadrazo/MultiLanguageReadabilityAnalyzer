package features;

import constants.TagKeys;
import datasetHelpers.Dataset;
import datasetHelpers.Text;

public class LanguageFeature implements Feature{

	
	private static final String TAG = TagKeys.TAG_LANGUAGE;
	
	public LanguageFeature() {
		
	}
	
	@Override
	public void applyFeature(Dataset d, Text t) {
		
		
	}

}
