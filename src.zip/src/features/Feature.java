package features;

import datasetHelpers.Dataset;
import datasetHelpers.Text;

public interface Feature {
	
	
	public void applyFeature(Dataset d, Text t);
	
}
