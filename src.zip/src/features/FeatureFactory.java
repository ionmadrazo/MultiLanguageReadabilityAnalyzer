package features;

import java.util.ArrayList;

public class FeatureFactory {

	
	public FeatureFactory()
	{
	
	}
	
	public ArrayList<Feature> createAllFeatures()
	{
		ArrayList<Feature> featureList = new ArrayList<>();
		return featureList;
	}
	
	public ArrayList<Feature> createShallowFeatures()
	{
		ArrayList<Feature> featureList = new ArrayList<>();
		return featureList;
	}
	
	
	
}
