package processors;

import datasetHelpers.Dataset;

public interface DatasetProcessor {

	
	
	public void process(Dataset d);
	
	
}
